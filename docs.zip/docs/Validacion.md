# Estado de verificación / revisión Aivora

- Se conserva sin modificación el código del motor, parámetros, conjunto de datos y métricas del proyecto anterior.
- Se recalculó en Python el vector de 11 características y la predicción exportada de los 450 pares: error máximo en variables 0, error máximo de probabilidad 3.33e-16, cero discrepancias de clase. Ver results/revision_validation.json. Esta NO es paridad Rust.
- Se verificó sintaxis Python de los scripts y sintaxis Node de build_variants.mjs. Se renderizaron documentos y presentación.
- Rust/cargo ausentes; npm install --offline falló por dependencias no cacheadas. No se verificó la compilación de Rust, Vite, Monaco, SiberUI ni el empaquetado Tauri. El paquete SiberUI usa el nombre original y requiere la versión/registro originales.
- No se midió el overhead de Monaco; se incluyen scripts para medirlo. No se declara compatibilidad multiplataforma verificada ni ejecución offline observada.
- La variante de referencia textarea debe verificarse sin chunks de Monaco en dist/ antes de comparar. El arranque hasta editores montados y fuentes listas no garantiza que el resaltado esté completo; validar sintaxis y worker offline aparte. RSS y CPU del árbol pueden excluir procesos compartidos de WebView.
- Los archivos de fuentes tipográficas se resuelven desde dependencias Fontsource durante la instalación; no se incluyen copias manuales. Los SVG de marca proporcionados se conservan.
