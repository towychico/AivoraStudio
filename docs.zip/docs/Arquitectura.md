# Diagramas editables (Mermaid)

## Componentes
```mermaid
flowchart TD
  subgraph Device[Dispositivo del usuario]
    UI[React JSX / SiberUI / Monaco local] -->|IPC local| IPC[Tauri compare_python]
    IPC -->|worker| V[Validación 64 KiB]
    V --> L[Lexer ligero]
    L --> F[11 variables]
    F --> M[Regresión logística]
    P[Pesos estáticos compilados] --> M
    F --> S[Score léxico]
    M --> R[DTO de resultados]
    S --> R
    R --> UI
  end
```

## Secuencia
```mermaid
sequenceDiagram
  actor U as Usuario
  participant R as React + Monaco
  participant T as Tauri IPC
  participant E as Motor Rust
  participant M as Modelo integrado
  U->>R: Pegar A/B y comparar
  R->>T: invoke compare_python
  T->>E: spawn_blocking
  E->>E: Validar y extraer 11 variables
  E->>M: predict(x)
  M-->>E: confianza
  E-->>T: score, confianza, clase, tiempos
  T-->>R: ResultDto
  R-->>U: Mostrar porcentajes si revisión vigente
```

## Entrenamiento y exportación
```mermaid
flowchart LR
  A[Dataset 3000 pares] --> B[Particiones originales]
  B --> C[Extracción Python]
  C --> D[Entrenar 3 clasificadores]
  D --> E[Validación F1 y tamaño]
  E --> F[Seleccionar logística]
  F --> G[Exportar model.rs]
  F --> H[Test 450 pares]
  H --> I[metrics.json y parity.tsv]
  G --> J[Compilación Rust]
  I --> K[Gate de paridad]
  J --> K
```

## Despliegue
```mermaid
flowchart TD
  A[Fuentes y herramientas de build] --> B[Build release por plataforma]
  B --> C[macOS / WebKit]
  B --> D[Windows / WebView2]
  B --> E[Linux / WebKitGTK]
  C --> F[Motor y parámetros integrados]
  D --> F
  E --> F
```

No hay servidor, endpoint HTTP de inferencia, base de datos, GPU ni Python en producción. Los diagramas representan el diseño propuesto; los builds y el comportamiento offline deben verificarse.

## Comparación de la capa de presentación
```mermaid
flowchart LR
 CLI[CLI Rust] --> E[Sovereign Engine]
 T[React / SiberUI / textarea] --> IPC[Tauri IPC]
 M[React / SiberUI / Monaco local] --> IPC
 IPC --> E
 E --> P[Pesos embebidos]
```
Los modelos y las variables son idénticos entre variantes. Las fuentes, workers y editor se incluyen como recursos del build de producción; no se consultan CDN.
